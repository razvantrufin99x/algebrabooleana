﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace algebrabooleana
{
    public class binarynumber
    {
        //on 4 bits from binar 0000 to 1111 sau deca 0 to 15
        public int a = 0;
        public int b = 0;
        public int c = 0;
        public int d = 0;



    }
}
